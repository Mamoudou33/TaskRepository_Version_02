package com.example.demo.model;

import javax.persistence.*;

@Entity
@Table(name="TaskData")
//@Table(name="TaskTable")
public class Task {
	@Id
	public int getTaskid() {
		return taskid;
	}
	public void setTaskid(int taskid) {
		this.taskid = taskid;
	}
	public String getTaskTitle() {
		return taskTitle;
	}
	public void setTaskTitle(String taskTitle) {
		this.taskTitle = taskTitle;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public String getAssignedTo() {
		return assignedTo;
	}
	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}
	int    taskid;
	String taskTitle;
	int    duration;
	String assignedTo;

}
